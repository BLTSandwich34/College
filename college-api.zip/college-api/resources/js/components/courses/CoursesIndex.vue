<template>
    <div class="card card-default">
        <div class="card-header">Course list</div>

        <div class="card-body">
            <div class="form-group">
                <router-link to="/courses/create" class="btn btn-success">Add new Course</router-link>

            </div>
            <p v-if="courses.length == 0">There are no courses</p>
            <table v-if="courses.length != 0">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Code</th>
                        <th>Description</th>
                        <th>Points</th>
                        <th>Level</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="course in courses">
                        <td>{{ course.title }}</td>
                        <td>{{ course.code }}</td>
                        <td>{{ course.description }}</td>
                        <td>{{ course.points }}</td>
                        <td>{{ course.level }}</td>
                        <td>
                          <router-link :to="{ name: 'editCourse', params: { id: course.id } }" class="btn btn-warning">Edit</router-link>
                          <button class= "btn btn-danger" v-on:click="deleteCourse(course.id)">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            var app = this;
            var token = localStorage.getItem('token');
            axios.get('/api/courses', {
                headers: { Authorization: "Bearer " + token }
            })
            .then(function (resp) {
                console.log(resp.data);
                app.courses = resp.data;
            })
            .catch(function (resp) {
                console.log(resp);
                alert('Could not load courses');
            });
        },
        data() {
            return {
                courses: []
            }
        },
        /**methods(){
            deleteCourse(){
                var app = this;
                confirm("Are you sure you want to delete the course(id = "+ courseId +")?");
                axios.delete('/api/courses/'+ courseId)
                .then(function (resp){
                    var index = courses.findIndex(function (course)){
                        return course.id == courseId;
                    }
                })
                app.courses.splice(index,1);
                .catch(function (resp){
                    alert("could not delete course");
                });
            }
        }**/
    }

</script>
