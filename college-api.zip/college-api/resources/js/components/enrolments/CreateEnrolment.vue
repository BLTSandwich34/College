<template>
    <div class="card card-default">
        <div class="card-header">Create enrolments</div>

        <div class="card-body">
            <form v-on:submit="saveForm()">
                <div class="form-row">
                /**These forms put the data into a from group with the errors */
                    <div class="col-md-6 form-group">
                        <label>Date</label>
                        <input type="text" v-model="enrolments.date" class="form-control">
                        <p class="text-danger" v-if="errors.date">{{ errors.date[0] }}</p>
                    </div>
                    <div class="col-md-6 form-group">
                        <label>Time</label>
                        <input type="text" v-model="enrolments.time" class="form-control">
                        <p class="text-danger" v-if="errors.time">{{ errors.time[0] }}</p>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-md-4 form-group">
                        <label>Status</label>
                        <select v-model="enrolments.status" class="form-control">
                        <option v-for = "status in enrolments" :value = "enrolment.id">
                            {{enrolments.status}}
                        </option>
                    </select>
                        <p class="text-danger" v-if="errors.status">{{ errors.status[0] }}</p>
                    </div>

                    <div class="col-md-4 form-group">
                        <label>Course</label>
                        <select v-model="enrolments.course_id" class="form-control">
                            <option v-for="course in courses" :value="course.id">
                                {{ course.name }}
                            </option>
                        </select>
                        <p class="text-danger" v-if="errors.course_id">{{ errors.course_id[0] }}</p>
                    </div>
                    <div class="col-md-4 form-group">
                        <label>Student</label>
                        <select v-model="enrolments.student_id" class="form-control">
                            <option v-for="student in students" :value="student.id">
                                {{ student.name }}
                            </option>
                        </select>
                        <p class="text-danger" v-if="errors.student_id">{{ errors.student_id[0] }}</p>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-md-12 form-group">
                        <button class="btn btn-primary">Update</button>
                        <router-link to="/" class="btn btn-secondary">Cancel</router-link>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
    export default {
    /**These returns the new enrolment data into an array as well as the data for the course and students.*/
        data: function () {
            return {
                enrolment: {
                    date: '',
                    time: '',
                    status: '',
                    course_id: '',
                    student_id: '',
                },
                courses: [],
                students: [],
                errors: {}
            }
        },
        mounted() {
            var app = this;
            axios.get('/api/courses')
            .then(function (resp) {
                console.log(resp.data);
                app.courses = resp.data;
            })
            .catch(function (resp) {
                console.log(resp);
                alert('Could not load course');
            });

            axios.get('/api/students')
            .then(function (resp) {
                console.log(resp.data);
                app.students = resp.data;
            })
            .catch(function (resp) {
                console.log(resp);
                alert('Could not load student');
            });
        },
        methods: {
            saveForm() {
                event.preventDefault();
                var app = this;
                var newEnrolment = app.enrolment;
                axios.put('/api/enrolments/' + id, newEnrolment)
                    .then(function (resp) {
                        app.$router.push({path: '/'});
                    })
                    .catch(function (resp) {
                        app.errors = resp.response.data;
                    });
            }
        }
    }
</script>
