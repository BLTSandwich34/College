
<template>
    <div class="card card-default">
        <div class="card-header">Enrolments list</div>

        <div class="card-body">
            <div class="form-group">
                <router-link to="/enrolments/create" class="btn btn-success">Add new enrolment</router-link>

            </div>

            <p v-if="enrolments.length == 0">There are no enrolments</p>
            <table v-if="enrolments.length != 0">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Course</th>
                        <th>Student</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>


                    <tr v-for="enrolment in enrolments">
                        <td>{{ enrolment.date }}</td>
                        <td>{{ enrolment.time }}</td>
                        <td>{{ enrolment.status }}</td>
                        <td>{{ enrolment.course.title }}</td>
                        <td>{{ enrolment.student.name }}</td>

                        <td>

                          <router-link :to="{ name: 'editEnrolment', params: { id: enrolment.id } }"
                          class="btn btn-warning">Edit</router-link>

                          <button class= "btn btn-danger" v-on:click="deleteEnrolment(enrolment.id)">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            var app = this;
            var token = localStorage.getItem('token');
            axios.get('/api/enrolments', {
                headers: { Authorization: "Bearer " + token }
            })
            //The then and catch checks to see if the api for enrolment is working and if it doesn't then loads an alert message.
            .then(function (resp) {
                console.log(resp.data);
                app.enrolments = resp.data;
            })
            .catch(function (resp) {
                console.log(resp);
                alert('Could not load enrolments');
            });
        },
        //this returns the enrolments in an array
        data() {
            return {
                enrolments: []
            }
        }
        //These methods are used to check the id of an enrolment and then if it finds it deletes after you have confirmed

        /**methods(){
            deleteEnrolment(){
                var app = this;
                confirm("Are you sure you want to delete this enrolment(id = "+ enrolmentId +")?");
                axios.delete('/api/enrolments/'+ enrolmentId)
                .then(function (resp){
                    var index = enrolments.findIndex(function (enrolment)){
                        return enrolment.id == enrolmentId;
                    }
                })
                app.enrolments.splice(index,1);
                .catch(function (resp){
                    alert("could not delete enrolment");
                });
            }
        } */

    }
</script>
