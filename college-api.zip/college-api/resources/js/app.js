/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries.

 */

require('./bootstrap');
import Vue from 'vue';
import VueRouter from 'vue-router';
import LoginForm from './components/auth/LoginForm.vue';
import UserHome from './components/home/UserHome.vue';
import EnrolmentsIndex from './components/enrolments/EnrolmentsIndex.vue';
import CreateEnrolment from './components/enrolments/CreateEnrolment.vue';
import EditEnrolment from './components/enrolments/EditEnrolment.vue';
import StudentsIndex from './components/students/StudentsIndex.vue';
import CoursesIndex from './components/courses/CoursesIndex.vue';
/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application

 */

Vue.use(VueRouter);
/**
these routes create path to the compoonents for the login and home page. the home page component
has its own path to the various pagea using the parent and children style of coding.
 */

const routes = [
    {
        path: '/',
        name: 'login',
        components: {
            loginForm: LoginForm
        }
    },
    {
        path: '/home',
        component: UserHome,
        name: 'home',
        children: [

            {
                path: 'enrolments',
                name: 'enrolments',
                component: EnrolmentsIndex
            },

            {
                path: 'students',
                name: 'students',
                component: StudentsIndex
            },
            {
                path: 'courses',
                name: 'courses',
                component: CoursesIndex
            },
            {
                path: '/enrolments/create',
                component: CreateEnrolment,
                name: 'createEnrolmet'
            },
            {
                path: '/enrolments/:id/edit',
                component: EditEnrolment,
                name: 'editEnrolment'
            }
        ]
    }
];

const router = new VueRouter({
    routes: routes
});

const app = new Vue({
    el: '#app',
    router: router
});
