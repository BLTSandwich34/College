-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2019 at 05:35 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` int(10) UNSIGNED NOT NULL,
  `level` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `title`, `code`, `description`, `points`, `level`, `created_at`, `updated_at`) VALUES
(1, 'Cloud computing', 'HF161', 'This seemed to listen, the whole window!\' \'Sure, it does, yer honour: but it\'s an arm, yer honour!\' \'Digging for apples, indeed!\' said the Queen, turning purple. \'I won\'t!\' said Alice. \'You must.', 229, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(2, 'Interaction design', 'UA441', 'Caterpillar; and it said in an undertone to the door, staring stupidly up into the garden at once; but, alas for poor Alice! when she had hoped) a fan and gloves--that is, if I only wish it was,\'.', 119, 7, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(3, 'Mobile computing', 'GT558', 'Alice, thinking it was talking in a ring, and begged the Mouse with an anxious look at a reasonable pace,\' said the Dormouse; \'--well in.\' This answer so confused poor Alice, \'to pretend to be said.', 175, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(4, 'Web design', 'XG798', 'And here poor Alice in a twinkling! Half-past one, time for dinner!\' (\'I only wish people knew that: then they wouldn\'t be in Bill\'s place for a moment to be otherwise than what you would seem to.', 352, 7, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(5, 'Data analytics and big data', 'RT085', 'I\'m afraid, sir\' said Alice, as she could. \'The Dormouse is asleep again,\' said the Gryphon: and Alice looked at it gloomily: then he dipped it into one of the Mock Turtle: \'crumbs would all wash.', 429, 10, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(6, 'Digital media', 'HV474', 'The master was an old crab, HE was.\' \'I never thought about it,\' added the Dormouse. \'Write that down,\' the King exclaimed, turning to the shore, and then nodded. \'It\'s no use in waiting by the.', 550, 9, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(7, 'Business information systems', 'VO541', 'The Antipathies, I think--\' (for, you see, Miss, this here ought to be sure; but I think that there was room for this, and after a minute or two, which gave the Pigeon the opportunity of showing off.', 384, 10, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(8, 'Computer vision', 'CY304', 'Quick, now!\' And Alice was beginning to write with one eye; \'I seem to see what would happen next. \'It\'s--it\'s a very fine day!\' said a whiting before.\' \'I can hardly breathe.\' \'I can\'t help that,\'.', 437, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(9, 'Distributed computing', 'ZD776', 'Footman went on so long that they would go, and broke off a bit hurt, and she was saying, and the cool fountains. CHAPTER VIII. The Queen\'s Croquet-Ground A large rose-tree stood near the King said.', 372, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(10, 'Computer security and forensics', 'VB569', 'Gryphon added \'Come, let\'s hear some of the gloves, and she could see this, as she could, and soon found out a new kind of thing that would be QUITE as much as she could even make out what she was a.', 238, 7, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(11, 'Computer architecture', 'XU185', 'In the very tones of her voice. Nobody moved. \'Who cares for you?\' said the Mouse. \'Of course,\' the Mock Turtle. \'Certainly not!\' said Alice very meekly: \'I\'m growing.\' \'You\'ve no right to think,\'.', 402, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(12, 'Database systems', 'BZ883', 'As there seemed to be done, I wonder?\' As she said to herself; \'I should think you can find it.\' And she began nibbling at the top of her little sister\'s dream. The long grass rustled at her for a.', 487, 7, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(13, 'Computer networks', 'XI603', 'Who for such dainties would not give all else for two reasons. First, because I\'m on the bank, with her face in some book, but I THINK I can do no more, whatever happens. What WILL become of me?.', 155, 7, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(14, 'Artifical intelligence', 'PK382', 'I\'m angry. Therefore I\'m mad.\' \'I call it sad?\' And she went on just as if a dish or kettle had been anxiously looking across the garden, and marked, with one finger pressed upon its forehead (the.', 272, 7, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(15, 'Image processing', 'KR228', 'I had not gone (We know it was quite out of the Shark, But, when the tide rises and sharks are around, His voice has a timid and tremulous sound.] \'That\'s different from what I like\"!\' \'You might.', 440, 9, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(16, 'Machine learning', 'WW581', 'Mock Turtle is.\' \'It\'s the thing at all. \'But perhaps it was as long as I tell you!\' But she did not quite know what it was: she was to get out at the bottom of a well?\' The Dormouse slowly opened.', 222, 10, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(17, 'Computer graphics', 'LV791', 'March Hare had just begun to repeat it, but her head struck against the door, and tried to beat them off, and Alice thought to herself, \'I wish you could manage it?) \'And what an ignorant little.', 467, 9, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(18, 'Operating systems', 'FL930', 'Alice; \'you needn\'t be so kind,\' Alice replied, rather shyly, \'I--I hardly know, sir, just at present--at least I know who I WAS when I was a little scream of laughter. \'Oh, hush!\' the Rabbit just.', 416, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(19, 'Software testing', 'YB049', 'Please, Ma\'am, is this New Zealand or Australia?\' (and she tried to get into her head. Still she went on: \'--that begins with a melancholy way, being quite unable to move. She soon got it out into.', 339, 9, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(20, 'Robotics and automation', 'SX431', 'After a minute or two she stood watching them, and considered a little, and then quietly marched off after the birds! Why, she\'ll eat a little way off, and that is rather a handsome pig, I think.\'.', 210, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18');

-- --------------------------------------------------------

--
-- Table structure for table `enrolments`
--

CREATE TABLE `enrolments` (
  `id` int(10) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` enum('registered','attending','deferred','withdrawn') COLLATE utf8mb4_unicode_ci NOT NULL,
  `course_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `enrolments`
--

INSERT INTO `enrolments` (`id`, `date`, `time`, `status`, `course_id`, `student_id`, `created_at`, `updated_at`) VALUES
(1, '2019-02-14', '22:21:00', 'deferred', 16, 12, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(2, '2019-03-22', '09:24:00', 'registered', 6, 9, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(3, '2019-01-30', '07:57:00', 'deferred', 19, 20, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(4, '2019-03-17', '00:01:00', 'registered', 13, 26, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(5, '2019-01-09', '06:37:00', 'attending', 4, 29, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(6, '2019-03-03', '01:44:00', 'deferred', 6, 24, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(7, '2019-04-02', '11:51:00', 'withdrawn', 17, 23, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(8, '2019-03-15', '21:49:00', 'attending', 3, 44, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(9, '2019-03-06', '11:49:00', 'attending', 5, 36, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(10, '2019-01-14', '09:04:00', 'registered', 6, 36, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(11, '2019-04-02', '06:27:00', 'withdrawn', 5, 15, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(12, '2019-02-04', '16:19:00', 'deferred', 18, 25, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(13, '2019-02-06', '11:49:00', 'attending', 9, 5, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(14, '2019-03-16', '20:48:00', 'deferred', 16, 22, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(15, '2019-01-30', '07:51:00', 'deferred', 4, 3, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(16, '2019-01-12', '18:03:00', 'registered', 7, 17, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(17, '2019-01-06', '16:02:00', 'deferred', 18, 13, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(18, '2019-02-23', '04:47:00', 'deferred', 18, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(19, '2019-01-28', '17:55:00', 'attending', 15, 11, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(20, '2019-03-04', '00:52:00', 'withdrawn', 4, 14, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(21, '2019-03-26', '12:45:00', 'attending', 6, 26, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(22, '2019-01-23', '12:36:00', 'deferred', 19, 46, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(23, '2019-01-27', '13:07:00', 'deferred', 13, 9, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(24, '2019-03-19', '04:25:00', 'withdrawn', 20, 16, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(25, '2019-03-12', '21:10:00', 'attending', 4, 20, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(26, '2019-01-31', '02:20:00', 'deferred', 3, 31, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(27, '2019-01-11', '14:24:00', 'deferred', 17, 48, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(28, '2019-01-05', '21:08:00', 'attending', 8, 27, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(29, '2019-03-24', '05:18:00', 'attending', 19, 12, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(30, '2019-01-29', '13:42:00', 'attending', 8, 17, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(31, '2019-03-07', '09:53:00', 'deferred', 2, 41, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(32, '2019-03-11', '19:59:00', 'attending', 5, 20, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(33, '2019-01-19', '04:28:00', 'deferred', 11, 17, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(34, '2019-01-13', '23:49:00', 'deferred', 7, 29, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(35, '2019-03-23', '08:09:00', 'registered', 7, 43, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(36, '2019-03-13', '00:32:00', 'registered', 15, 35, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(37, '2019-03-26', '22:44:00', 'withdrawn', 11, 38, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(38, '2019-03-20', '19:21:00', 'attending', 14, 41, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(39, '2019-02-27', '16:32:00', 'withdrawn', 14, 46, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(40, '2019-01-14', '10:21:00', 'withdrawn', 8, 4, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(41, '2019-04-03', '06:27:00', 'registered', 4, 1, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(42, '2019-03-11', '16:59:00', 'registered', 12, 26, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(43, '2019-03-26', '21:17:00', 'withdrawn', 5, 45, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(44, '2019-01-10', '04:52:00', 'attending', 20, 15, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(45, '2019-01-10', '11:51:00', 'withdrawn', 6, 30, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(46, '2019-01-21', '22:47:00', 'deferred', 12, 37, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(47, '2019-01-26', '04:28:00', 'deferred', 19, 19, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(48, '2019-03-11', '16:40:00', 'attending', 6, 45, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(49, '2019-01-14', '08:05:00', 'attending', 17, 1, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(50, '2019-03-07', '07:16:00', 'registered', 11, 7, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(51, '2019-01-27', '01:18:00', 'deferred', 2, 26, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(52, '2019-01-27', '23:48:00', 'withdrawn', 7, 45, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(53, '2019-01-06', '17:47:00', 'deferred', 5, 33, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(54, '2019-02-03', '10:05:00', 'withdrawn', 10, 26, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(55, '2019-02-17', '01:52:00', 'registered', 17, 22, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(56, '2019-03-07', '18:21:00', 'registered', 6, 43, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(57, '2019-03-05', '17:58:00', 'withdrawn', 1, 49, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(58, '2019-04-03', '05:18:00', 'withdrawn', 6, 29, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(59, '2019-02-17', '08:14:00', 'deferred', 16, 5, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(60, '2019-01-05', '11:22:00', 'withdrawn', 11, 28, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(61, '2019-03-31', '00:32:00', 'deferred', 9, 3, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(62, '2019-02-03', '01:15:00', 'deferred', 16, 21, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(63, '2019-02-22', '08:41:00', 'registered', 19, 37, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(64, '2019-02-13', '23:46:00', 'registered', 20, 38, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(65, '2019-01-29', '12:05:00', 'deferred', 13, 28, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(66, '2019-02-12', '14:36:00', 'withdrawn', 7, 20, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(67, '2019-01-20', '15:28:00', 'withdrawn', 18, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(68, '2019-03-01', '11:23:00', 'deferred', 9, 22, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(69, '2019-02-10', '17:31:00', 'registered', 15, 47, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(70, '2019-03-29', '02:51:00', 'deferred', 4, 3, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(71, '2019-02-17', '22:11:00', 'attending', 1, 49, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(72, '2019-01-24', '16:40:00', 'withdrawn', 2, 45, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(73, '2019-02-19', '14:48:00', 'registered', 8, 48, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(74, '2019-02-03', '00:15:00', 'deferred', 12, 10, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(75, '2019-02-09', '16:49:00', 'attending', 4, 11, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(76, '2019-02-09', '05:40:00', 'attending', 4, 31, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(77, '2019-03-20', '15:56:00', 'deferred', 12, 49, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(78, '2019-03-15', '02:03:00', 'deferred', 12, 45, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(79, '2019-03-03', '19:55:00', 'withdrawn', 10, 15, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(80, '2019-03-06', '13:56:00', 'attending', 6, 40, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(81, '2019-03-10', '04:19:00', 'attending', 11, 50, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(82, '2019-03-07', '00:33:00', 'registered', 16, 45, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(83, '2019-03-17', '22:01:00', 'withdrawn', 7, 12, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(84, '2019-02-28', '14:39:00', 'deferred', 20, 32, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(85, '2019-02-22', '20:36:00', 'withdrawn', 9, 4, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(86, '2019-03-24', '12:53:00', 'registered', 12, 17, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(87, '2019-02-03', '10:29:00', 'deferred', 15, 39, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(88, '2019-03-30', '02:27:00', 'withdrawn', 19, 23, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(89, '2019-02-24', '15:04:00', 'attending', 17, 48, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(90, '2019-02-06', '04:34:00', 'registered', 7, 12, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(91, '2019-01-26', '11:40:00', 'registered', 19, 14, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(92, '2019-03-20', '02:10:00', 'deferred', 12, 48, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(93, '2019-02-26', '01:14:00', 'deferred', 16, 22, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(94, '2019-03-12', '10:49:00', 'attending', 19, 47, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(95, '2019-03-24', '09:27:00', 'registered', 9, 11, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(96, '2019-01-20', '07:03:00', 'attending', 6, 50, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(97, '2019-03-16', '21:41:00', 'withdrawn', 4, 34, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(98, '2019-02-26', '03:41:00', 'registered', 4, 43, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(99, '2019-03-07', '14:40:00', 'withdrawn', 19, 22, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(100, '2019-02-12', '12:35:00', 'deferred', 8, 43, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(101, '2019-03-08', '19:25:00', 'registered', 14, 23, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(102, '2019-01-29', '08:33:00', 'attending', 14, 25, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(103, '2019-03-12', '13:03:00', 'registered', 17, 10, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(104, '2019-03-20', '05:25:00', 'attending', 9, 33, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(105, '2019-03-03', '13:53:00', 'attending', 19, 30, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(106, '2019-02-22', '16:39:00', 'registered', 2, 32, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(107, '2019-02-01', '19:28:00', 'registered', 16, 13, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(108, '2019-01-22', '20:18:00', 'withdrawn', 7, 48, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(109, '2019-01-21', '23:06:00', 'withdrawn', 15, 17, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(110, '2019-01-19', '07:00:00', 'withdrawn', 10, 21, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(111, '2019-03-29', '07:37:00', 'attending', 9, 25, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(112, '2019-03-19', '16:25:00', 'registered', 11, 42, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(113, '2019-01-27', '19:16:00', 'deferred', 7, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(114, '2019-01-04', '11:24:00', 'attending', 9, 4, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(115, '2019-04-02', '09:55:00', 'registered', 14, 22, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(116, '2019-03-12', '18:02:00', 'deferred', 2, 3, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(117, '2019-03-14', '07:18:00', 'deferred', 16, 49, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(118, '2019-02-17', '04:49:00', 'deferred', 3, 15, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(119, '2019-02-24', '07:53:00', 'attending', 17, 6, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(120, '2019-01-08', '01:09:00', 'deferred', 9, 30, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(121, '2019-01-28', '07:42:00', 'withdrawn', 1, 48, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(122, '2019-01-04', '22:37:00', 'registered', 12, 26, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(123, '2019-02-14', '09:14:00', 'registered', 11, 1, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(124, '2019-02-26', '10:11:00', 'registered', 19, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(125, '2019-02-13', '13:50:00', 'withdrawn', 2, 16, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(126, '2019-02-17', '20:50:00', 'attending', 5, 11, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(127, '2019-03-27', '20:03:00', 'attending', 8, 32, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(128, '2019-01-05', '08:50:00', 'withdrawn', 4, 4, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(129, '2019-02-19', '03:35:00', 'registered', 9, 20, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(130, '2019-03-28', '01:06:00', 'deferred', 8, 10, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(131, '2019-01-23', '21:33:00', 'attending', 4, 34, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(132, '2019-01-08', '08:30:00', 'deferred', 17, 26, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(133, '2019-02-26', '10:35:00', 'registered', 12, 15, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(134, '2019-03-14', '10:57:00', 'withdrawn', 6, 30, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(135, '2019-02-14', '04:03:00', 'attending', 9, 35, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(136, '2019-02-04', '05:42:00', 'registered', 8, 6, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(137, '2019-01-17', '23:52:00', 'withdrawn', 2, 17, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(138, '2019-03-20', '11:25:00', 'attending', 8, 38, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(139, '2019-03-28', '22:55:00', 'withdrawn', 7, 18, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(140, '2019-01-04', '15:13:00', 'deferred', 16, 22, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(141, '2019-03-29', '13:22:00', 'deferred', 1, 50, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(142, '2019-02-02', '12:29:00', 'attending', 12, 44, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(143, '2019-01-16', '01:44:00', 'registered', 8, 13, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(144, '2019-04-02', '02:36:00', 'registered', 18, 44, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(145, '2019-01-07', '06:24:00', 'deferred', 3, 22, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(146, '2019-03-29', '15:54:00', 'deferred', 11, 19, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(147, '2019-01-10', '15:00:00', 'registered', 15, 6, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(148, '2019-02-04', '04:14:00', 'registered', 12, 39, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(149, '2019-01-09', '16:29:00', 'withdrawn', 15, 38, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(150, '2019-01-26', '11:54:00', 'registered', 2, 29, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(151, '2019-03-17', '13:28:00', 'registered', 19, 16, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(152, '2019-01-11', '15:38:00', 'registered', 5, 37, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(153, '2019-03-14', '07:24:00', 'deferred', 8, 27, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(154, '2019-01-27', '06:49:00', 'registered', 19, 4, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(155, '2019-03-11', '13:05:00', 'deferred', 12, 19, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(156, '2019-01-09', '07:40:00', 'deferred', 14, 26, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(157, '2019-01-25', '11:31:00', 'deferred', 3, 6, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(158, '2019-01-11', '09:52:00', 'withdrawn', 4, 31, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(159, '2019-04-01', '08:27:00', 'registered', 18, 21, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(160, '2019-01-16', '04:12:00', 'registered', 14, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(161, '2019-02-23', '07:48:00', 'registered', 12, 36, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(162, '2019-01-25', '18:35:00', 'deferred', 20, 26, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(163, '2019-02-14', '00:13:00', 'attending', 15, 21, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(164, '2019-02-04', '11:14:00', 'attending', 17, 22, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(165, '2019-01-18', '19:39:00', 'withdrawn', 12, 32, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(166, '2019-01-21', '22:35:00', 'registered', 10, 35, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(167, '2019-02-12', '18:32:00', 'deferred', 4, 46, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(168, '2019-02-05', '22:20:00', 'deferred', 6, 43, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(169, '2019-01-06', '06:33:00', 'deferred', 9, 45, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(170, '2019-02-08', '17:15:00', 'registered', 9, 34, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(171, '2019-01-18', '05:46:00', 'registered', 11, 6, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(172, '2019-01-14', '22:32:00', 'attending', 15, 23, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(173, '2019-03-21', '16:47:00', 'deferred', 12, 49, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(174, '2019-01-19', '20:21:00', 'withdrawn', 11, 11, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(175, '2019-02-13', '00:24:00', 'deferred', 2, 28, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(176, '2019-01-22', '19:01:00', 'attending', 13, 31, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(177, '2019-01-21', '02:25:00', 'withdrawn', 5, 17, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(178, '2019-02-21', '05:07:00', 'attending', 3, 25, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(179, '2019-03-29', '09:35:00', 'deferred', 17, 13, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(180, '2019-04-04', '00:44:00', 'registered', 20, 26, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(181, '2019-01-10', '09:22:00', 'registered', 3, 24, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(182, '2019-01-23', '16:07:00', 'deferred', 13, 46, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(183, '2019-01-31', '22:00:00', 'withdrawn', 5, 19, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(184, '2019-03-28', '01:41:00', 'attending', 2, 15, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(185, '2019-01-21', '14:11:00', 'deferred', 6, 30, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(186, '2019-02-10', '03:11:00', 'registered', 8, 41, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(187, '2019-03-14', '13:42:00', 'attending', 4, 43, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(188, '2019-02-07', '20:32:00', 'deferred', 12, 10, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(189, '2019-04-02', '04:41:00', 'deferred', 8, 31, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(190, '2019-01-27', '12:11:00', 'registered', 6, 5, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(191, '2019-02-14', '18:43:00', 'registered', 1, 31, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(192, '2019-03-12', '02:09:00', 'attending', 5, 37, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(193, '2019-02-12', '21:25:00', 'registered', 6, 17, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(194, '2019-03-23', '04:06:00', 'withdrawn', 7, 34, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(195, '2019-03-26', '12:31:00', 'registered', 9, 28, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(196, '2019-01-20', '16:57:00', 'withdrawn', 18, 6, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(197, '2019-03-07', '03:56:00', 'withdrawn', 5, 43, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(198, '2019-01-20', '03:54:00', 'withdrawn', 10, 31, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(199, '2019-03-04', '20:36:00', 'withdrawn', 9, 4, '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(200, '2019-01-11', '21:17:00', 'attending', 17, 8, '2019-04-04 09:29:18', '2019-04-04 09:29:18');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2018_11_15_124259_create_courses_table', 1),
(9, '2018_11_15_124314_create_students_table', 1),
(10, '2018_11_15_124330_create_enrolments_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('522bddacef98a565bee79e61c5a0c51ac1e1604c50b3c2e6c9539ae796c2e3939cfbc9d695c5b6dc', 1, 1, 'Medical-Centre', '[]', 0, '2019-04-04 10:01:48', '2019-04-04 10:01:48', '2020-04-04 11:01:48'),
('6ab4e46bc9d3c9cc3f1dd5a3ca5d5bde95b1243aa4cb49e5393a91baf13fb9d8af5fd35af8564feb', 1, 1, 'Medical-Centre', '[]', 0, '2019-04-11 08:36:02', '2019-04-11 08:36:02', '2020-04-11 09:36:02'),
('fb72f2aaba90a7a3a7555c284894a5eb8abac62a40939f3b65d3f7ae36e7984db96c274ee96f7d3b', 1, 1, 'Medical-Centre', '[]', 0, '2019-04-11 08:33:35', '2019-04-11 08:33:35', '2020-04-11 09:33:35');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'J4qxIQVHLFeJNSkp8TK0FnsnOzfMGDomq5QlKdG8', 'http://localhost', 1, 0, 0, '2019-04-04 09:50:28', '2019-04-04 09:50:28'),
(2, NULL, 'Laravel Password Grant Client', 'wEoOQwkZFNqJ7syNU6qAe048U9hT594VYg17FGns', 'http://localhost', 0, 1, 0, '2019-04-04 09:50:28', '2019-04-04 09:50:28');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2019-04-04 09:50:28', '2019-04-04 09:50:28');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `address`, `email`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'Marcia Sawayn', '92 Billie Lakes, Millsshire', 'lindsay05@hotmail.com', '016-2648262', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(2, 'Raheem Schamberger', '83 Considine Ports, Jevonport', 'champlin.august@bartoletti.com', '095-8631809', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(3, 'Annalise Johns', '73 Iliana Grove, Laurelview', 'west.jude@gmail.com', '013-7620622', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(4, 'Prof. Judson Hayes', '66 Hansen Inlet, Garrickfurt', 'pedro49@sawayn.org', '040-0587551', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(5, 'Mr. Jerry Gutkowski Sr.', '31 Unique Summit, Elwinville', 'cielo72@schmitt.net', '021-8517034', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(6, 'Deron Quigley', '37 Paxton Gateway, Hughview', 'savanah37@yahoo.com', '084-1860672', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(7, 'Prof. Madelyn Medhurst', '95 O\'Hara Forks, Dariobury', 'ckohler@yahoo.com', '080-0586998', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(8, 'Prof. Nicole Eichmann PhD', '44 Schroeder Turnpike, Fletcherville', 'scarlett.treutel@jenkins.biz', '067-8068862', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(9, 'Mallie Johnson DVM', '100 Baby Cliff, Carterburgh', 'leannon.nikki@stokes.com', '037-8280387', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(10, 'Dr. Thomas Nader', '32 Rachael Turnpike, Lake Aprilville', 'lavinia.hoppe@klein.info', '073-6279579', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(11, 'Neha Wisoky', '34 Marianna Brook, Lockmanhaven', 'lucio.runte@gmail.com', '048-4966471', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(12, 'Ebba Kovacek', '86 Miller Spur, Port Uriah', 'imcclure@williamson.com', '089-1427623', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(13, 'Elsie Walter', '4 Welch Locks, Augustineburgh', 'trey62@hotmail.com', '060-5215493', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(14, 'Maia Leannon', '39 Bart Ramp, North Ransomchester', 'dwintheiser@cruickshank.com', '065-7424991', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(15, 'Dr. Rosendo Keeling', '1 Haylee Trail, Purdyburgh', 'jacques.gleason@hotmail.com', '099-8182493', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(16, 'Madelyn Kohler', '79 Collins Park, Lake Glen', 'hegmann.russ@deckow.com', '086-2139704', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(17, 'Prof. Chanelle Bashirian', '97 Gage Views, North Ezra', 'klittel@torp.com', '083-3222314', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(18, 'Gardner Hudson', '5 Nicola Shoals, South Tod', 'lind.providenci@ledner.com', '016-1057952', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(19, 'Javon Boyle', '3 Cordia Ramp, Valeriemouth', 'haylie.mertz@yahoo.com', '071-0876044', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(20, 'Emmalee Collier', '82 Davis Ramp, West Rick', 'emmy.wuckert@kerluke.org', '021-5199765', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(21, 'Fanny Greenfelder', '3 Tiffany Light, East Tamarahaven', 'mitchel.roberts@yahoo.com', '080-9277055', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(22, 'Miss Elsa Moen MD', '91 Barrows Island, West Tevin', 'urice@nolan.com', '051-1138962', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(23, 'Clare Rath', '26 Hamill Parks, Lake Mandy', 'dlangosh@gmail.com', '088-6452224', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(24, 'Helene Konopelski IV', '55 Feeney Lane, New Melba', 'luigi68@buckridge.net', '064-4594230', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(25, 'Donald Feeney', '58 Adeline Brooks, Kathleenside', 'dion45@terry.com', '011-6949939', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(26, 'Britney Gleason', '32 Torp Route, North John', 'erich30@predovic.info', '098-4920764', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(27, 'Ayla Hills', '49 Ethyl Ferry, West Annette', 'ohara.filiberto@considine.com', '034-1581718', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(28, 'Myrtie Mayer', '31 Floy Landing, Treverstad', 'ewunsch@yahoo.com', '023-8232990', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(29, 'Yasmeen Schimmel', '91 VonRueden Creek, West Ethaport', 'qhagenes@yahoo.com', '043-4156078', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(30, 'Polly Berge', '60 Macy Plaza, Deliaberg', 'zion52@gmail.com', '017-6902439', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(31, 'Elda Hand', '26 McGlynn Route, Carissaville', 'lynch.fanny@kulas.com', '067-0434633', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(32, 'Golden Cremin IV', '51 Johns Stravenue, Daynehaven', 'emante@hotmail.com', '028-2351250', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(33, 'Daron Kessler', '53 Doyle Trace, New Ezequielburgh', 'fredrick32@bernhard.com', '006-4467289', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(34, 'Crawford Nitzsche II', '75 Dasia Pines, South Enid', 'geovanni11@hotmail.com', '086-2478051', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(35, 'Aglae Cassin', '53 Ettie Roads, Ambroseberg', 'edmond34@gmail.com', '031-6863050', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(36, 'Lessie Rath', '89 Crist Square, Gunnarchester', 'jordy.heathcote@gmail.com', '097-2775588', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(37, 'Benjamin Daniel', '23 Josefa Island, Port Carson', 'kevin.harris@gmail.com', '034-2806590', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(38, 'Roxane Kassulke III', '61 Lauryn Manor, North Francesco', 'mmann@gmail.com', '035-0813090', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(39, 'Fleta Kemmer II', '39 Johns Spring, East Delia', 'yasmeen04@cronin.com', '028-7591434', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(40, 'Valerie Ruecker', '57 Kelvin Heights, Port Luefort', 'flabadie@dicki.com', '076-0691296', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(41, 'Dr. Abdiel Will Sr.', '42 Octavia Camp, Baileyland', 'hoyt32@oberbrunner.com', '047-5368803', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(42, 'Betty Howe', '62 Otho Highway, Sarinatown', 'bnikolaus@towne.com', '016-0483390', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(43, 'Pink Schultz', '50 Ankunding Rapids, Lake Kieranview', 'chet.kuphal@schuppe.com', '082-2257111', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(44, 'Christine Kreiger', '25 Albina Crest, Josefaville', 'dooley.kristina@nader.com', '043-7597585', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(45, 'Prof. Greta O\'Connell', '15 Cummerata Union, North Allene', 'kallie.johns@harber.com', '028-4431397', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(46, 'Danika Ziemann', '21 Marilie Viaduct, Port Raheemborough', 'zpouros@gmail.com', '043-5305987', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(47, 'Mabelle Klein', '50 Lou Streets, South Idellmouth', 'cbayer@hotmail.com', '071-8032313', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(48, 'Napoleon Wolf Jr.', '37 Stiedemann Ridges, West Fred', 'cole.eliseo@yahoo.com', '059-5344305', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(49, 'Karine King', '63 Johnson Tunnel, Hillstad', 'bennett.ledner@feest.biz', '090-5557680', '2019-04-04 09:29:18', '2019-04-04 09:29:18'),
(50, 'Jaeden Smith', '18 Beer Islands, Tierraburgh', 'hilbert80@rohan.com', '062-8099574', '2019-04-04 09:29:18', '2019-04-04 09:29:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Sam Bloggs', 'sam@bloggs.com', NULL, '$2y$10$.M.EZ6tVIpiWDltMdotmNuAdf0V8GqJW9.5iLpc0tIv5NTEpuTw7i', NULL, '2019-04-04 09:29:18', '2019-04-04 09:29:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enrolments`
--
ALTER TABLE `enrolments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `enrolments_course_id_foreign` (`course_id`),
  ADD KEY `enrolments_student_id_foreign` (`student_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `students_email_unique` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `enrolments`
--
ALTER TABLE `enrolments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `enrolments`
--
ALTER TABLE `enrolments`
  ADD CONSTRAINT `enrolments_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  ADD CONSTRAINT `enrolments_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
